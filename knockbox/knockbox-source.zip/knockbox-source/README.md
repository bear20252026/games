# Knockbox 前端源代码（https://knockbox.app/b/59gww8uvzq）

抓取时间：2026-11-24。目标页：`fUji · a beat by bizzle`（bizzle 做的 beat，链接 id `59gww8uvzq`）。

这份目录是**浏览器实际拿到的全部前端源代码与静态资源**，按站点原始路径保存，未做压缩、未做混淆——拿到的就是带注释、按模块拆分的源码。

## 目录结构

```
index.html                站点首页外壳（单页应用，所有界面由 JS 渲染）
b/59gww8uvzq/
  index.html              你给的那条链接返回的原始 HTML（含 beat 的 meta / OG 标签）
  card.png                该 beat 的分享卡片图
beat-59gww8uvzq.json      该 beat 的完整数据快照（/api/beats/59gww8uvzq 的返回）
src/
  main.js                 入口模块，装配整张“工作台”
  main.css                主样式（约 215 KB，未压缩）
  stickers.css
  components/             41 个 UI 组件（Grid、Mixer、RecordBox、VoxLane、Tour…）
  core/                   68 个核心模块（AudioEngine、Clock、HumanizeEngine、
                          GrooveController、MidiExporter、AudioExporter、
                          ClipExporter、VoxEngine、Packing、Disks…）
  workers/                3 个 Web Worker
  constants/drums.js      鼓组映射（KICK/SNARE/HI-HAT/OPEN HH，GM 音高 36/38/42/46）
public/
  images/                 唱片封套、宝丽来照片、Logo、标签贴纸
  faces/                  16 个头像 SVG
  stickers/               3 张贴纸（drums / pocket / chop）
  3dModels/head_bob.riv   Rive 动画（5.3 MB）
  loops/sozo/runes.wav    内置采样 loop（3 MB）
  loops/records.json      内置唱片清单
favicon.* / site.webmanifest
```

合计 156 个文件、约 10 MB。已校验 247 处模块 `import`，全部能在本地对上，无缺失模块。

## 本地打开

在 `knockbox-src` 目录里起一个静态服务器（ES module 不能用 `file://` 直接打开）：

```
python -m http.server 8123
```

然后访问 `http://127.0.0.1:8123/`。界面、点格子、听鼓、摇摆参数、导出 MIDI/WAV 这些**纯前端逻辑**都在这份代码里；账号、保存磁盘、Crate 电台、分享这些要走 `/api/*` 的功能会 404，因为后端不在这份源码里（服务端代码从不下发到浏览器，抓不到）。

## 外部依赖（不在本地，需联网）

- `@rive-app/canvas@2.34.0` — importmap 指向 jsDelivr CDN，Rive 头像动画用
- Google Fonts（JetBrains Mono、Permanent Marker）
- Cloudflare Turnstile 与 Insights 脚本

## 那条链接的 beat 数据

`beat-59gww8uvzq.json` 里有完整快照：标题 `fUji`、BPM 88、标签 `88 BPM / FRICTION / DRUNK 68 / LOOP`，以及 4 轨 × 16 步的 step 网格：

```
step   0123456789012345
KICK   X..X...X...X....
SNARE  ....X.......X...
HIHAT  X.X.X.X.X.X.X.XX
OPENHH ..........X.....
```

作者 bizzle（头像 moon），发布时带音频，被播放 14 次，挂在 Crate 里。

## 说明

源码版权归 Knockbox 作者所有，这里只是把公开可访问的前端文件做了一份本地镜像，供阅读、学习、离线调试用；别拿去直接商用或二次分发。
